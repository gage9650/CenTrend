import React, { useState } from 'react';
import { ArrowLeft, RotateCw, TrendingDown, TrendingUp } from 'lucide-react';
import { mockStockData } from '../mockData';
import { StockItem } from '../types';

interface StockDetailViewProps {
  stock?: StockItem | null;
  onBack: () => void;
}

export const StockDetailView: React.FC<StockDetailViewProps> = ({ stock, onBack }) => {
  const [activeFilter, setActiveFilter] = useState<'1일' | '5일' | '1개월' | '6개월' | '1년'>('5일');
  const [hoverData, setHoverData] = useState<{ time: string; value: number } | null>(null);

  const displayStock: StockItem = stock || {
    id: 'qqq',
    name: '인베스코 QQQ 신탁',
    ticker: 'QQQ',
    price: '670.15',
    currency: 'USD',
    changeRate: '5.41%',
    isUp: false,
    category: '미국 ETF',
  };

  const filters = ['1일', '5일', '1개월', '6개월', '1년'] as const;

  // Calculate min and max for chart bounds
  const values = mockStockData.map((d) => d.value);
  const minVal = Math.min(...values) - 5;
  const maxVal = Math.max(...values) + 5;

  const points = mockStockData
    .map((d, i) => {
      const x = (i / (mockStockData.length - 1)) * 300;
      const y = 140 - ((d.value - minVal) / (maxVal - minVal)) * 120;
      return `${x},${y}`;
    })
    .join(' ');

  const isUp = displayStock.isUp;
  const strokeColor = isUp ? '#10B981' : '#EF4444';

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-12 animate-fade-in">
      {/* Back Button */}
      <button
        onClick={onBack}
        className="flex items-center gap-1.5 text-xs font-semibold text-gray-600 hover:text-black transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>브리핑으로</span>
      </button>

      {/* Stock Subheader & Title */}
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs font-semibold text-gray-400">{displayStock.name}</p>
          <h1 className="text-3xl font-extrabold text-gray-900 tracking-tight mt-0.5 flex items-center gap-2">
            {displayStock.ticker}
            {displayStock.category && (
              <span className="text-xs font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-100">
                {displayStock.category}
              </span>
            )}
          </h1>
          <div className="flex items-baseline gap-3 mt-1">
            <span className="text-3xl font-extrabold text-gray-900">
              {hoverData ? hoverData.value.toFixed(2) : displayStock.price}
            </span>
            <span className="text-xs font-bold text-gray-400">{displayStock.currency}</span>
            <div
              className={`flex items-center gap-1 font-bold text-sm px-2.5 py-0.5 rounded-full border ${
                isUp
                  ? 'text-emerald-700 bg-emerald-50 border-emerald-200'
                  : 'text-red-600 bg-red-50 border-red-100'
              }`}
            >
              {isUp ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
              <span>{displayStock.changeRate}</span>
            </div>
          </div>
          <p className="text-xs text-gray-400 flex items-center gap-1.5 mt-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span>실시간 시세</span>
          </p>
        </div>

        <button 
          onClick={() => {}}
          className="flex items-center gap-1.5 text-xs font-semibold text-gray-500 hover:text-gray-900 bg-white hover:bg-gray-50 border border-gray-200 px-3 py-1.5 rounded-xl transition-all shadow-2xs"
        >
          <RotateCw className="w-3.5 h-3.5" />
          <span>새로고침</span>
        </button>
      </div>

      {/* Time Filters */}
      <div className="flex items-center gap-2">
        {filters.map((filter) => (
          <button
            key={filter}
            onClick={() => setActiveFilter(filter)}
            className={`px-3.5 py-1.5 text-xs font-bold rounded-full transition-all ${
              activeFilter === filter
                ? 'bg-black text-white shadow-xs'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            {filter}
          </button>
        ))}
      </div>

      {/* Main Stock Line Chart Container */}
      <div className="bg-white rounded-3xl p-6 border border-gray-200/90 shadow-xs relative">
        <div className="relative h-64 w-full">
          <svg
            className="w-full h-full overflow-visible"
            viewBox="0 0 300 150"
            preserveAspectRatio="none"
          >
            <defs>
              <linearGradient id="stockGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={strokeColor} stopOpacity="0.25" />
                <stop offset="100%" stopColor={strokeColor} stopOpacity="0.0" />
              </linearGradient>
            </defs>

            {/* Area Fill */}
            <polygon
              points={`0,150 ${points} 300,150`}
              fill="url(#stockGradient)"
            />

            {/* Main Line */}
            <polyline
              fill="none"
              stroke={strokeColor}
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
              points={points}
            />

            {/* Hover Points */}
            {mockStockData.map((d, i) => {
              const x = (i / (mockStockData.length - 1)) * 300;
              const y = 140 - ((d.value - minVal) / (maxVal - minVal)) * 120;
              return (
                <circle
                  key={i}
                  cx={x}
                  cy={y}
                  r="4"
                  className="fill-white stroke-2 cursor-pointer hover:r-6 transition-all"
                  style={{ stroke: strokeColor }}
                  onMouseEnter={() => setHoverData(d)}
                  onMouseLeave={() => setHoverData(null)}
                />
              );
            })}
          </svg>
        </div>

        {/* X Axis Time Labels */}
        <div className="flex justify-between items-center text-[10px] text-gray-400 mt-4 border-t border-gray-100 pt-3">
          <span>오전 01:15</span>
          <span>오후 10:45</span>
          <span>오전 02:45</span>
          <span>오전 12:15</span>
          <span>오전 04:15</span>
          <span>오전 01:45</span>
          <span>오후 11:32</span>
        </div>
      </div>

      {/* Footer Disclaimer */}
      <p className="text-[11px] text-gray-400 leading-relaxed text-center">
        시세는 Yahoo Finance 공개 데이터를 기반으로 하며, 실제 거래 기준 시세와 약간의 시차가 있을 수 있어요. 15초마다 자동으로 새로고침돼요.
      </p>
    </div>
  );
};
