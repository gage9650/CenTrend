import React, { useState } from 'react';
import { UserRank, User } from '../types';
import { Crown, Trophy, Sparkles } from 'lucide-react';

interface RankingViewProps {
  rankings: UserRank[];
  currentUser: User | null;
}

export const RankingView: React.FC<RankingViewProps> = ({
  rankings,
  currentUser,
}) => {
  const [period, setPeriod] = useState<'주간' | '월간' | '전체'>('주간');

  const getRankBadge = (rank: number) => {
    switch (rank) {
      case 1:
        return (
          <div className="w-7 h-7 rounded-full bg-amber-400 text-amber-950 font-extrabold text-xs flex items-center justify-center shadow-2xs">
            🥇
          </div>
        );
      case 2:
        return (
          <div className="w-7 h-7 rounded-full bg-slate-300 text-slate-900 font-extrabold text-xs flex items-center justify-center shadow-2xs">
            🥈
          </div>
        );
      case 3:
        return (
          <div className="w-7 h-7 rounded-full bg-amber-700 text-amber-100 font-extrabold text-xs flex items-center justify-center shadow-2xs">
            🥉
          </div>
        );
      default:
        return (
          <div className="w-7 h-7 rounded-full bg-gray-100 text-gray-700 font-bold text-xs flex items-center justify-center">
            {rank}
          </div>
        );
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-12 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 tracking-tight flex items-center gap-2">
            학습왕 유저 랭킹 <Crown className="w-6 h-6 text-amber-500 fill-amber-400" />
          </h1>
          <p className="text-xs text-gray-500 mt-1">
            열정적으로 경제 및 투자 만화를 학습하고 경험치(XP)를 쌓은 우수 유저 순위입니다.
          </p>
        </div>

        {/* Time Period Filter */}
        <div className="flex items-center gap-1 bg-white p-1 rounded-full border border-gray-200 shadow-2xs self-start sm:self-auto">
          {(['주간', '월간', '전체'] as const).map((p) => (
            <button
              key={p}
              onClick={() => setPeriod(p)}
              className={`px-3 py-1 text-xs font-bold rounded-full transition-all ${
                period === p ? 'bg-gray-950 text-white shadow-2xs' : 'text-gray-500 hover:text-gray-900'
              }`}
            >
              {p}
            </button>
          ))}
        </div>
      </div>

      {/* User Status Card */}
      {currentUser && (
        <div className="bg-gradient-to-r from-emerald-700 to-teal-800 text-white rounded-3xl p-5 shadow-sm flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-xs flex items-center justify-center font-extrabold text-sm border border-white/30">
              {currentUser.avatar}
            </div>
            <div>
              <p className="text-xs text-emerald-200 font-semibold">나의 현재 랭킹</p>
              <p className="text-base font-extrabold">{currentUser.name} (5위)</p>
            </div>
          </div>

          <div className="text-right">
            <p className="text-xs text-emerald-200 font-semibold">보유 경험치</p>
            <p className="text-base font-extrabold">{currentUser.xp} XP (Lv.{currentUser.level})</p>
          </div>
        </div>
      )}

      {/* USERS RANKING LIST */}
      <div className="space-y-3">
        {rankings.map((userRank) => (
          <div
            key={userRank.rank}
            className={`rounded-3xl p-5 border transition-all flex items-center justify-between ${
              userRank.rank === 5
                ? 'bg-emerald-50/60 border-emerald-300 shadow-2xs'
                : 'bg-white border-gray-200/90 shadow-2xs'
            }`}
          >
            <div className="flex items-center gap-4">
              {getRankBadge(userRank.rank)}

              <div className="w-10 h-10 rounded-2xl bg-gray-900 text-white font-bold text-sm flex items-center justify-center shrink-0">
                {userRank.avatar}
              </div>

              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-extrabold text-gray-900">{userRank.name}</h3>
                  <span className="text-[10px] font-extrabold bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded-md">
                    Lv.{userRank.level}
                  </span>
                </div>
                <p className="text-xs text-gray-400 mt-0.5">
                  연속 학습 {userRank.streak}일 · 배지 {userRank.badges}개
                </p>
              </div>
            </div>

            <div className="text-right">
              <p className="text-sm font-extrabold text-gray-900">{userRank.xp} XP</p>
              <span className="text-[10px] font-bold text-emerald-600">상위 {userRank.rank * 2}%</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
