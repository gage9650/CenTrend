import { NewsArticle, CommunityPost, Quest, Badge, UserRank, User, StockItem } from './types';

export const initialUser: User = {
  id: 'user_1',
  name: '이슬',
  avatar: '이',
  level: 2,
  xp: 50,
  nextLevelXp: 500,
  streakDays: 0,
  interests: ['바이오', '테슬라', 'QQQ'],
  readArticlesCount: 6,
  earnedBadgesCount: 0,
};

export const mockArticles: NewsArticle[] = [
  {
    id: 'art-1',
    category: '반도체',
    readStatus: true,
    title: "NVIDIA, 차세대 AI 칩 '루빈' 양산 일정 앞당긴다",
    source: '테크브리핑',
    publishedTime: '2시간 전',
    readTime: '3분 읽기',
    impactRating: 5,
    iconType: 'chip',
    summary: '엔비디아가 블랙웰의 다음 세대인 루빈 AI GPU 양산 타임라인을 2026년 상반기로 단축하여 기술 주도권을 확고히 합니다.',
    likesCount: 142,
    commentsCount: 28,
    keyTakeaways: [
      '차세대 루빈 아키텍처는 HBM4를 탑재하여 연산 속도를 3배 향상시킵니다.',
      '양산 시점이 6개월 앞당겨지면서 관련 반도체 공급망에 큰 호재로 작용합니다.',
      '삼성전자와 SK하이닉스의 HBM4 수주 경쟁이 더욱 치열해질 전망입니다.'
    ],
    cartoonPanels: [
      {
        panelNumber: 1,
        title: '1컷: 속도전 개시!',
        sceneDescription: '엔비디아 CEO 젠슨 황이 루빈 칩 로드맵 서류를 들고 당당하게 서있다.',
        characterSpeaker: '젠슨 황',
        speechBubble: 'AI 시장이 너무 가파르게 성장해요! 차세대 칩 "루빈" 양산을 6개월 앞당깁니다!',
        visualIcon: 'building',
        keyTerm: '루빈 (Rubin)',
        keyTermDefinition: '엔비디아의 차세대 AI 전용 아키텍처로 HBM4 메모리가 탑재될 예정입니다.'
      },
      {
        panelNumber: 2,
        title: '2컷: 왜 앞당길까?',
        sceneDescription: '빅테크 기업들이 AI 데이터센터 서버에 엄청난 돈을 쏟아붓고 있는 그래프.',
        characterSpeaker: '빅테크 수장',
        speechBubble: '더 빠른 AI 처리 속도가 필요해요! 얼른 칩을 공급해주세요!',
        visualIcon: 'handshake',
        keyTerm: 'AI 가속기',
        keyTermDefinition: '딥러닝 연산을 전문적으로 빠르게 처리하기 위해 특화된 반도체 칩셋입니다.'
      },
      {
        panelNumber: 3,
        title: '3컷: 메모리 반도체의 미소',
        sceneDescription: 'SK하이닉스와 삼성전자 캐릭터가 HBM4 메모리를 들고 웃고 있다.',
        characterSpeaker: 'K-반도체',
        speechBubble: '루빈에는 차세대 HBM4가 필수! 우리 고성능 메모리 수요가 폭발하겠네요!',
        visualIcon: 'chart',
        keyTerm: 'HBM4',
        keyTermDefinition: '4세대 고대역폭 메모리로 반도체 칩을 세로로 쌓아 전송 속도를 극대화한 기술입니다.'
      },
      {
        panelNumber: 4,
        title: '4컷: 투자 시장 영향',
        sceneDescription: '주가 그래프가 우상향하며 개미 캐릭터가 돋보기를 들고 분석하는 모습.',
        characterSpeaker: '투자자 개미',
        speechBubble: 'AI 반도체 생태계 전반에 큰 온기가 돌겠군요! 공급망 체인을 주목해봅시다.',
        visualIcon: 'graduation',
        keyTerm: '공급망 (Supply Chain)',
        keyTermDefinition: '제품 생산부터 최종 전달까지의 모든 기업과 프로세스 연결망입니다.'
      }
    ]
  },
  {
    id: 'art-2',
    category: '금리',
    readStatus: true,
    title: "미국 중앙은행, 이번 달 금리 동결... 시장은 '안도'",
    source: '글로벌경제',
    publishedTime: '5시간 전',
    readTime: '4분 읽기',
    impactRating: 4,
    iconType: 'bank',
    summary: '연준이 기준금리를 동결하면서 물가 안정세와 경기 침체 우려 사이에서 균형을 잡았습니다.',
    likesCount: 98,
    commentsCount: 15,
    keyTakeaways: [
      '기준금리가 현 수준인 5.25~5.50%로 유지되었습니다.',
      '인플레이션 지표 하락으로 하반기 금리 인하 가능성이 높아졌습니다.',
      '기술주 위주의 증시가 불확실성 해소로 상승세를 보였습니다.'
    ],
    cartoonPanels: [
      {
        panelNumber: 1,
        title: '1컷: 연준의 결정',
        sceneDescription: '제롬 파월 의장이 망치를 들고 기준금리 동결을 선언하는 장면.',
        characterSpeaker: '파월 의장',
        speechBubble: '이번 달은 금리를 그대로 유지하겠습니다! 물가 반응을 더 지켜보죠.',
        visualIcon: 'bank',
        keyTerm: '기준금리',
        keyTermDefinition: '한 국가의 금리 체계의 기준이 되는 정책 금리입니다.'
      },
      {
        panelNumber: 2,
        title: '2컷: 시장의 반응',
        sceneDescription: '월스트리트 증권가 수사자 캐릭터가 안도의 한숨을 쉬고 있다.',
        characterSpeaker: '월가 애널리스트',
        speechBubble: '휴~ 금리가 추가로 오르지 않아서 다행이에요! 불확실성이 걷혔네요.',
        visualIcon: 'chart',
        keyTerm: '금리 동결',
        keyTermDefinition: '기준금리를 올리거나 내리지 않고 현재 수준으로 유지하는 결정입니다.'
      },
      {
        panelNumber: 3,
        title: '3컷: 인플레이션의 기세',
        sceneDescription: '물가 불꽃 캐릭터가 점차 작아지는 시각적 표현.',
        characterSpeaker: '물가 캐릭터',
        speechBubble: '높았던 물가 상승세가 조금씩 진정되고 있어요.',
        visualIcon: 'handshake',
        keyTerm: '인플레이션',
        keyTermDefinition: '통화량이 늘어나 화폐가치가 떨어지고 물가가 지속적으로 오르는 현상입니다.'
      },
      {
        panelNumber: 4,
        title: '4컷: 앞으로의 전망',
        sceneDescription: '하반기 금리 인하 기대감에 환호하는 주식 시장.',
        characterSpeaker: '스마트 개미',
        speechBubble: '하반기 피벗(금리 인하 전환) 가능성이 커지면서 증시 환경이 좋아지고 있어요!',
        visualIcon: 'graduation',
        keyTerm: '피벗 (Pivot)',
        keyTermDefinition: '통화 정책 기조를 긴축에서 완화로 전환하는 것을 의미합니다.'
      }
    ]
  },
  {
    id: 'art-3',
    category: '반도체',
    readStatus: true,
    title: "삼성전자, 3분기 실적발표에서 반도체 부문 '깜짝 흑자'",
    source: '머니투데이',
    publishedTime: '어제',
    readTime: '3분 읽기',
    impactRating: 4,
    iconType: 'phone',
    summary: '메모리 가격 상승과 고용량 D램 수요 급증으로 반도체 부문 실적이 대폭 개선되었습니다.',
    likesCount: 112,
    commentsCount: 19,
    keyTakeaways: [
      'D램 및 낸드플래시 감산 효과로 반도체 가격이 상승했습니다.',
      '서버용 메모리 반도체 공급 확대로 영업이익이 컨센서스를 상회했습니다.',
      '파운드리 수주 확대 여부가 향후 주가의 핵심 변수입니다.'
    ],
    cartoonPanels: [
      {
        panelNumber: 1,
        title: '1컷: 어닝 서프라이즈!',
        sceneDescription: '삼성전자 대표 캐릭터가 3분기 실적 성적표를 들고 환호한다.',
        characterSpeaker: '삼성이',
        speechBubble: '3분기 영업이익이 예상을 훌륭하게 훌쩍 넘겼습니다! 반도체의 힘!',
        visualIcon: 'chart',
        keyTerm: '어닝 서프라이즈',
        keyTermDefinition: '기업의 영업 실적 발표가 증권가의 예상치를 뛰어넘는 호실적을 낸 경우입니다.'
      },
      {
        panelNumber: 2,
        title: '2컷: 감산의 힘',
        sceneDescription: '메모리 창고에 재고가 줄어들고 가격표가 올라가는 모습.',
        characterSpeaker: '메모리 칩',
        speechBubble: '그동안 생산량을 줄인 덕분에 공급 과잉이 해소되고 메모리 가격이 반등했어요!',
        visualIcon: 'building',
        keyTerm: 'D램 (DRAM)',
        keyTermDefinition: '전원이 꺼지면 데이터가 사라지지만 매우 빠른 임시 기억 장치입니다.'
      },
      {
        panelNumber: 3,
        title: '3컷: AI 데이터센터의 러브콜',
        sceneDescription: '글로벌 서버 기업들이 고용량 DDR5를 주문하러 줄서있다.',
        characterSpeaker: '글로벌 서포터',
        speechBubble: 'AI 데이터센터에는 고용량 DDR5 메모리가 어마어마하게 많이 필요합니다!',
        visualIcon: 'handshake',
        keyTerm: 'DDR5',
        keyTermDefinition: 'DDR4 대비 속도가 2배 이상 빠르고 전력 효율이 뛰어난 최신 D램 규격입니다.'
      },
      {
        panelNumber: 4,
        title: '4컷: 투자포인트 체크',
        sceneDescription: '차트를 분석하며 넥스트 행보를 보는 투자자.',
        characterSpeaker: '투자 전문가',
        speechBubble: '메모리 업황의 본격적 회복 신호입니다! 파운드리 부문의 향방도 주목하세요.',
        visualIcon: 'graduation',
        keyTerm: '파운드리 (Foundry)',
        keyTermDefinition: '반도체 설계 전문 기업(팹리스)으로부터 위탁받아 반도체를 전문 생산하는 공장입니다.'
      }
    ]
  },
  {
    id: 'art-4',
    category: '반도체',
    readStatus: true,
    title: "SK하이닉스, HBM 공급 부족에 가격 협상력 '쑥'",
    source: '테크브리핑',
    publishedTime: '2일 전',
    readTime: '4분 읽기',
    impactRating: 4,
    iconType: 'box',
    summary: 'AI 호황으로 인한 HBM 수요 폭발로 내년 물량까지 완판되며 우월한 가격 결정력을 확보했습니다.',
    likesCount: 85,
    commentsCount: 11,
    keyTakeaways: [
      'HBM3E 8단 및 12단 제품이 글로벌 대기업에 독점 공급 중입니다.',
      '2025년 생산 물량까지 이미 완판된 것으로 파악됩니다.',
      '높은 마진율로 사상 최대 영업이익률 달성이 기대됩니다.'
    ],
    cartoonPanels: [
      {
        panelNumber: 1,
        title: '1컷: 품귀 현상',
        sceneDescription: 'HBM 메모리가 박스째 쌓여있고 구매자들이 줄서서 기다린다.',
        characterSpeaker: '하이닉스 양',
        speechBubble: '죄송해요! 내년 생산 물량까지 이미 완판되어서 예약 구매하셔야 해요!',
        visualIcon: 'box',
        keyTerm: '완판 (Sold Out)',
        keyTermDefinition: '생산 예정인 고성능 메모리 물량이 모두 계약 완료된 상태입니다.'
      },
      {
        panelNumber: 2,
        title: '2컷: 가격 협상력 우위',
        sceneDescription: '가격표를 제시하자 구매자 기업들이 고개를 끄덕인다.',
        characterSpeaker: '글로벌 Big Tech',
        speechBubble: '얼마든 지급할 테니 제발 우리 데이터센터에 우선 공급해주세요!',
        visualIcon: 'handshake',
        keyTerm: '가격 결정력',
        keyTermDefinition: '독보적 기술력이나 공급 부족 상황에서 판매자가 가격을 올릴 수 있는 권한입니다.'
      },
      {
        panelNumber: 3,
        title: '3컷: HBM3E 12단의 위엄',
        sceneDescription: '12층으로 겹겹이 스택된 초고속 HBM3E 미니어처 모델.',
        characterSpeaker: '기술 연구원',
        speechBubble: '12단을 완벽히 적층하여 수율과 안정성을 모두 높였습니다!',
        visualIcon: 'chart',
        keyTerm: '수율 (Yield)',
        keyTermDefinition: '전체 결함 없는 양품 반도체 비율을 뜻하는 핵심 제조 효율 지표입니다.'
      },
      {
        panelNumber: 4,
        title: '4컷: 수익성 극대화',
        sceneDescription: '높은 이익률 지표를 보며 웃는 주주들의 모습.',
        characterSpeaker: '행복한 주주',
        speechBubble: '고마진 제품 판매 확대로 이익률이 사상 최고치를 갱신하고 있어요!',
        visualIcon: 'graduation',
        keyTerm: '영업이익률',
        keyTermDefinition: '매출액 대비 영업이익의 비율로 기업의 수익 창출 능력을 나타냅니다.'
      }
    ]
  },
  {
    id: 'art-5',
    category: '전기차',
    readStatus: true,
    title: "테슬라, 완전자율주행(FSD) 구독자 수 '역대 최대' 경신",
    source: '오토뉴스',
    publishedTime: '1일 전',
    readTime: '2분 읽기',
    impactRating: 3,
    iconType: 'car',
    summary: '인공지능 신경망 기반 FSD V12 업그레이드로 자율주행 성능이 획기적으로 향상되어 구독자가 폭증했습니다.',
    likesCount: 76,
    commentsCount: 22,
    keyTakeaways: [
      '엔드투엔드(End-to-End) AI 모델 도입으로 운전이 한층 부드러워졌습니다.',
      '로보택시(Robotaxi) 상용화 기대감이 가시화되고 있습니다.',
      '자율주행 소프트웨어 구독 매출이 테슬라의 고마진 수익원으로 자리잡았습니다.'
    ],
    cartoonPanels: [
      {
        panelNumber: 1,
        title: '1컷: 운전대가 스스로 척척!',
        sceneDescription: '테슬라 차 안에서 운전자가 편안하게 커피를 마시고 차가 자율주행한다.',
        characterSpeaker: '테슬라 오너',
        speechBubble: '신호등도 보고 복잡한 교차로도 완벽하게 스스로 통과해요!',
        visualIcon: 'car',
        keyTerm: 'FSD (Full Self-Driving)',
        keyTermDefinition: '테슬라의 심화된 완전 자율주행 지원 소프트웨어 패키지입니다.'
      },
      {
        panelNumber: 2,
        title: '2컷: AI 신경망의 혁신',
        sceneDescription: '코딩 코드 대신 수백만 개의 운전 영상 데이터가 AI로 흡수되는 모션.',
        characterSpeaker: '일론 머스크',
        speechBubble: 'C++ 코드를 다 없애고 순수 AI 인공지능 신경망이 운전을 직접 학습하게 했습니다!',
        visualIcon: 'chip',
        keyTerm: 'End-to-End AI',
        keyTermDefinition: '카메라 영상 입력부터 핸들·브레이크 제어 출력까지 인공지능이 직접 처리하는 방식입니다.'
      },
      {
        panelNumber: 3,
        title: '3컷: 구독자 수 폭발',
        sceneDescription: '월 구독 결제 버튼을 누르는 운전자들이 늘어나는 그래프.',
        characterSpeaker: '테슬라 유저들',
        speechBubble: '월 $99면 이 편리함을 누릴 수 있다니! 당연히 구독해야죠!',
        visualIcon: 'handshake',
        keyTerm: '구독 모델 (SaaS)',
        keyTermDefinition: '소프트웨어를 매달 일정 금액을 내고 이용하는 비즈니스 방식입니다.'
      },
      {
        panelNumber: 4,
        title: '4컷: 로보택시 시대로',
        sceneDescription: '무인 로보택시가 도심을 달리는 미래지향적 일러스트.',
        characterSpeaker: '미래 자율주행자',
        speechBubble: '소프트웨어 마진이 엄청나군요! 로보택시 사업의 청사진이 또렷해집니다.',
        visualIcon: 'graduation',
        keyTerm: '로보택시',
        keyTermDefinition: '운전자 없이 자율주행 기술로만 승객을 태워 운행하는 무인 택시 서비스입니다.'
      }
    ]
  },
  {
    id: 'art-6',
    category: 'ETF',
    readStatus: true,
    title: "국내 대표 ETF 'TIGER AI반도체', 상장 후 최대 자금 유입",
    source: '펀드투데이',
    publishedTime: '3일 전',
    readTime: '2분 읽기',
    impactRating: 3,
    iconType: 'box',
    summary: 'AI 반도체 밸류체인 핵심 기업에 분산투자하는 ETF로 개인과 기관 자금이 대거 몰렸습니다.',
    likesCount: 64,
    commentsCount: 9,
    keyTakeaways: [
      '한 번의 매수로 한미반도체, SK하이닉스 등 주요 AI 반도체주에 동시 투자합니다.',
      '개인 순매수가 연일 최고치를 기록하며 대세 테마로 부상했습니다.',
      '변동성을 줄이면서 상방 열린 산업 성장에 참여하는 효과적인 방법입니다.'
    ],
    cartoonPanels: [
      {
        panelNumber: 1,
        title: '1컷: 어떤 종목을 사야 하지?',
        sceneDescription: '고민하는 초보 투자자 개미가 종목들을 바라보고 있다.',
        characterSpeaker: '초보 개미',
        speechBubble: 'AI 반도체가 좋은 건 아는데... 개별 종목은 변동성이 커서 무서워요!',
        visualIcon: 'box',
        keyTerm: 'ETF',
        keyTermDefinition: '주식처럼 거래소에서 쉽게 사고팔 수 있는 상장지수 펀드입니다.'
      },
      {
        panelNumber: 2,
        title: '2컷: 종합선물세트 등장!',
        sceneDescription: 'TIGER AI반도체 ETF 상자에 여러 반도체 기업 주식이 담겨 있다.',
        characterSpeaker: '펀드 매니저',
        speechBubble: '그렇다면 AI 반도체 1등 기업들을 모아놓은 ETF 1주를 사시면 됩니다!',
        visualIcon: 'handshake',
        keyTerm: '분산 투자',
        keyTermDefinition: '여러 종목에 자금을 나누어 투자하여 위험을 줄이는 투자 기법입니다.'
      },
      {
        panelNumber: 3,
        title: '3컷: 기록적인 자금 유입',
        sceneDescription: '자금 차곡차곡 쌓이는 저금통과 그래프.',
        characterSpeaker: '시장 분석가',
        speechBubble: '개인 투자자들의 뭉칫돈이 들어오면서 순자산 총액이 급증했습니다!',
        visualIcon: 'chart',
        keyTerm: '순자산 (AUM)',
        keyTermDefinition: '펀드에 모인 총 자산 가치 금액입니다.'
      },
      {
        panelNumber: 4,
        title: '4컷: 똑똑한 자산 배분',
        sceneDescription: '포트폴리오에 ETF를 편입하고 미소짓는 유저.',
        characterSpeaker: '스마트 투자자',
        speechBubble: '산업 전체의 성장에 안정적으로 탑승하는 현명한 전략이군요!',
        visualIcon: 'graduation',
        keyTerm: '포트폴리오',
        keyTermDefinition: '투자자가 보유한 주식, 펀드 등 자산의 조합입니다.'
      }
    ]
  }
];

export const mockCommunityPosts: CommunityPost[] = [
  {
    id: 'post-1',
    title: '⚡ 젠슨 황의 연설 한 문장 요약! 엔비디아 루빈 칩 4컷 만화',
    category: '인기 만화',
    authorName: '반도체마스터',
    authorLevel: 12,
    authorAvatar: '반',
    createdAt: '1시간 전',
    likesCount: 234,
    commentsCount: 32,
    isLiked: false,
    newsTitle: "NVIDIA, 차세대 AI 칩 '루빈' 양산 일정 앞당긴다",
    summary: '젠슨 황의 속도전과 한국 HBM 반도체 동맹의 승리를 귀여운 그림체로 4컷 만화 구성해봤습니다!',
    cartoonPanels: mockArticles[0].cartoonPanels,
    views: 1540,
    comments: [
      {
        id: 'c-1',
        authorName: '주린이탈출',
        authorAvatar: '주',
        authorLevel: 3,
        content: '4컷 만화로 보니까 HBM4가 왜 중요한지 한눈에 이해돼요! 추천 누르고 갑니다 👍',
        createdAt: '45분 전',
        likes: 18,
        isLiked: false
      },
      {
        id: 'c-2',
        authorName: '엔비디아주주',
        authorAvatar: '엔',
        authorLevel: 8,
        content: '젠슨 황 캐릭터 대사가 너무 찰지네요 ㅋㅋㅋ 루빈 출시 기대해봅니다!',
        createdAt: '30분 전',
        likes: 12,
        isLiked: false
      },
      {
        id: 'c-3',
        authorName: '금리분석가',
        authorAvatar: '금',
        authorLevel: 6,
        content: '용어 설명 팝업 기능이 있어서 확실히 공부에 도움이 돼요.',
        createdAt: '10분 전',
        likes: 5,
        isLiked: false
      }
    ]
  },
  {
    id: 'post-2',
    title: '🏦 파월 할아버지의 금리 동결 이야기 (초보 추천!)',
    category: '개념 추천',
    authorName: '경제학도',
    authorLevel: 7,
    authorAvatar: '경',
    createdAt: '3시간 전',
    likesCount: 189,
    commentsCount: 21,
    isLiked: true,
    newsTitle: "미국 중앙은행, 이번 달 금리 동결... 시장은 '안도'",
    summary: '기준금리와 인플레이션의 관계를 유머러스하게 그려봤습니다. 시장이 왜 기뻐했는지 이해하기 쉬워요.',
    cartoonPanels: mockArticles[1].cartoonPanels,
    views: 1210,
    comments: [
      {
        id: 'c-4',
        authorName: '알뜰통장',
        authorAvatar: '알',
        authorLevel: 4,
        content: '피벗 개념 매번 헷갈렸는데 4컷으로 한 번에 정립 완료!',
        createdAt: '2시간 전',
        likes: 9,
        isLiked: false
      }
    ]
  },
  {
    id: 'post-3',
    title: '🚘 테슬라 FSD V12 무인운전 AI의 비밀',
    category: '기술 분석',
    authorName: '테슬라홀릭',
    authorLevel: 15,
    authorAvatar: '테',
    createdAt: '5시간 전',
    likesCount: 145,
    commentsCount: 18,
    isLiked: false,
    newsTitle: "테슬라, 완전자율주행(FSD) 구독자 수 '역대 최대' 경신",
    summary: '엔드투엔드 AI가 뭔지 어렵게 설명하지 않고 4컷 만화로 핵심만 정리!',
    cartoonPanels: mockArticles[4].cartoonPanels,
    views: 980,
    comments: []
  }
];

export const mockRankings: UserRank[] = [
  { rank: 1, name: '반도체마스터', level: 18, xp: 8420, streak: 42, badges: 12, avatar: '반' },
  { rank: 2, name: '테슬라홀릭', level: 15, xp: 6900, streak: 28, badges: 10, avatar: '테' },
  { rank: 3, name: '엔비디아주주', level: 14, xp: 6150, streak: 31, badges: 9, avatar: '엔' },
  { rank: 4, name: '경제학도', level: 12, xp: 5200, streak: 19, badges: 8, avatar: '경' },
  { rank: 5, name: '이슬 (나)', level: 2, xp: 50, streak: 0, badges: 0, avatar: '이' },
];

export const mockQuests: Quest[] = [
  {
    id: 'q-1',
    title: 'ETF 이해하기',
    description: 'ETF가 등장하는 기사 3개를 읽고 개념을 완전히 익혀보세요.',
    category: '개념 학습',
    currentCount: 3,
    targetCount: 3,
    rewardXp: 120,
    isCompleted: true,
    icon: 'check'
  },
  {
    id: 'q-2',
    title: 'AI 반도체 배우기',
    description: 'AI와 반도체가 만나는 지점을 다룬 기사 5개를 읽어보세요.',
    category: '테마 학습',
    currentCount: 4,
    targetCount: 5,
    rewardXp: 180,
    isCompleted: false,
    icon: 'brain'
  },
  {
    id: 'q-3',
    title: '금리 배우기',
    description: '금리가 시장에 미치는 영향을 다룬 기사 4개를 읽어보세요.',
    category: '거시경제',
    currentCount: 2,
    targetCount: 4,
    rewardXp: 150,
    isCompleted: false,
    icon: 'bank'
  },
  {
    id: 'q-4',
    title: '실적발표 시즌 완주하기',
    description: '실적발표 관련 기사 3개를 읽고 흐름을 파악해 보세요.',
    category: '기업 분석',
    currentCount: 2,
    targetCount: 3,
    rewardXp: 100,
    isCompleted: false,
    icon: 'chart'
  },
  {
    id: 'q-5',
    title: '7일 연속 브리핑 챙겨보기',
    description: '매일 오늘의 브리핑을 확인하고 연속 기록을 이어가 보세요.',
    category: '습관 형성',
    currentCount: 0,
    targetCount: 7,
    rewardXp: 200,
    isCompleted: false,
    icon: 'flame'
  }
];

export const mockBadges: Badge[] = [
  { id: 'b-1', title: 'ETF 마스터', icon: 'box', isUnlocked: false, description: 'ETF 기사 3개 완독 달성' },
  { id: 'b-2', title: '반도체 탐험가', icon: 'brain', isUnlocked: false, description: '반도체 관련 기사 5개 완독' },
  { id: 'b-3', title: '금리 해설가', icon: 'bank', isUnlocked: false, description: '금리 관련 기사 완독' },
  { id: 'b-4', title: '7일 연속 브리핑', icon: 'flame', isUnlocked: false, description: '일주일 연속 학습 달성' },
  { id: 'b-5', title: '첫 발걸음', icon: 'seed', isUnlocked: true, description: '첫 번째 4컷만화 뉴스 완독' },
];

export const defaultStockList: StockItem[] = [
  {
    id: 'qqq',
    name: '인베스코 QQQ 신탁',
    ticker: 'QQQ',
    price: '670.15',
    currency: 'USD',
    changeRate: '5.41%',
    isUp: false,
    category: '미국 ETF',
  },
  {
    id: 'nvda',
    name: '엔비디아 Corporation',
    ticker: 'NVDA',
    price: '128.50',
    currency: 'USD',
    changeRate: '3.82%',
    isUp: true,
    category: 'AI 반도체',
  },
  {
    id: 'tsla',
    name: '테슬라 Inc',
    ticker: 'TSLA',
    price: '248.20',
    currency: 'USD',
    changeRate: '1.95%',
    isUp: true,
    category: '전기차/자율주행',
  },
  {
    id: 'samsung',
    name: '삼성전자',
    ticker: '005930',
    price: '78,500',
    currency: 'KRW',
    changeRate: '0.64%',
    isUp: true,
    category: 'K-반도체',
  },
  {
    id: 'aapl',
    name: '애플 Inc',
    ticker: 'AAPL',
    price: '224.30',
    currency: 'USD',
    changeRate: '0.45%',
    isUp: false,
    category: '빅테크',
  },
  {
    id: 'spy',
    name: 'SPDR S&P 500 ETF',
    ticker: 'SPY',
    price: '542.10',
    currency: 'USD',
    changeRate: '0.28%',
    isUp: true,
    category: '지수 ETF',
  },
];

export const mockStockData = [
  { time: '오전 01:15', value: 708.9 },
  { time: '오전 02:45', value: 706.2 },
  { time: '오전 04:15', value: 709.1 },
  { time: '오전 05:45', value: 708.5 },
  { time: '오전 07:15', value: 705.0 },
  { time: '오전 08:45', value: 698.4 },
  { time: '오전 10:15', value: 691.2 },
  { time: '오프 11:45', value: 692.0 },
  { time: '오후 01:15', value: 680.5 },
  { time: '오후 02:45', value: 683.1 },
  { time: '오후 04:15', value: 678.9 },
  { time: '오후 05:45', value: 681.4 },
  { time: '오후 07:15', value: 673.2 },
  { time: '오후 08:45', value: 675.0 },
  { time: '오후 10:15', value: 663.1 },
  { time: '오후 11:32', value: 670.15 },
];
