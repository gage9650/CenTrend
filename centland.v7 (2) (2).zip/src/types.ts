export interface StockItem {
  id: string;
  name: string;
  ticker: string;
  price: string;
  currency: string;
  changeRate: string;
  isUp: boolean;
  category?: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  avatar: string;
  level: number;
  xp: number;
  nextLevelXp: number;
  streakDays: number;
  interests: string[];
  readArticlesCount: number;
  earnedBadgesCount: number;
}

export interface CartoonPanel {
  panelNumber: number;
  title: string;
  sceneDescription: string;
  characterSpeaker?: string;
  speechBubble: string;
  visualIcon?: string; // e.g. 'building', 'handshake', 'chart', 'graduation'
  keyTerm?: string;
  keyTermDefinition?: string;
}

export interface NewsArticle {
  id: string;
  category: string; // 반도체, 금리, 전기차, ETF 등
  readStatus: boolean;
  title: string;
  source: string;
  publishedTime: string;
  readTime: string;
  impactRating: number; // 1 to 5
  iconType: 'chip' | 'bank' | 'phone' | 'car' | 'box' | 'chart';
  summary: string;
  likesCount: number;
  commentsCount: number;
  cartoonPanels: CartoonPanel[];
  keyTakeaways: string[];
}

export interface Comment {
  id: string;
  authorName: string;
  authorAvatar: string;
  authorLevel: number;
  content: string;
  createdAt: string;
  likes: number;
  isLiked?: boolean;
}

export interface CommunityPost {
  id: string;
  title: string;
  category: string;
  authorName: string;
  authorLevel: number;
  authorAvatar: string;
  createdAt: string;
  likesCount: number;
  commentsCount: number;
  isLiked?: boolean;
  newsTitle?: string;
  summary: string;
  cartoonPanels: CartoonPanel[];
  comments: Comment[];
  views: number;
}

export interface Quest {
  id: string;
  title: string;
  description: string;
  category: string;
  currentCount: number;
  targetCount: number;
  rewardXp: number;
  isCompleted: boolean;
  icon: string;
}

export interface Badge {
  id: string;
  title: string;
  icon: string;
  isUnlocked: boolean;
  description: string;
}

export interface UserRank {
  rank: number;
  name: string;
  level: number;
  xp: number;
  streak: number;
  badges: number;
  avatar: string;
}
