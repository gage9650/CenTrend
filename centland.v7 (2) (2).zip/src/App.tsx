import React, { useState } from 'react';
import { 
  NewsArticle, 
  CommunityPost, 
  User, 
  Quest, 
  Badge, 
  UserRank,
  StockItem 
} from './types';
import { 
  initialUser, 
  mockArticles, 
  mockCommunityPosts, 
  mockQuests, 
  mockBadges, 
  mockRankings 
} from './mockData';
import { Header } from './components/Header';
import { Sidebar, TabType } from './components/Sidebar';
import { TodayBriefing } from './components/TodayBriefing';
import { NewsComicModal } from './components/NewsComicModal';
import { StockDetailView } from './components/StockDetailView';
import { QuestsView } from './components/QuestsView';
import { ProfileView } from './components/ProfileView';
import { CommunityView } from './components/CommunityView';
import { RankingView } from './components/RankingView';
import { LoginModal } from './components/LoginModal';
import { LandingPage } from './components/LandingPage';

export default function App() {
  const [user, setUser] = useState<User | null>(initialUser);
  const [activeTab, setActiveTab] = useState<TabType>('briefing');
  const [isLanding, setIsLanding] = useState<boolean>(false);
  const [showLoginModal, setShowLoginModal] = useState<boolean>(false);

  // Core Data States
  const [articles, setArticles] = useState<NewsArticle[]>(mockArticles);
  const [communityPosts, setCommunityPosts] = useState<CommunityPost[]>(mockCommunityPosts);
  const [quests, setQuests] = useState<Quest[]>(mockQuests);
  const [badges, setBadges] = useState<Badge[]>(mockBadges);
  const [rankings, setRankings] = useState<UserRank[]>(mockRankings);

  // Selected Article for 4-panel comic view
  const [selectedArticle, setSelectedArticle] = useState<NewsArticle | null>(null);
  const [showStockDetail, setShowStockDetail] = useState<boolean>(false);
  const [selectedStock, setSelectedStock] = useState<StockItem | undefined>(undefined);

  // AI Generation Loading State
  const [isGenerating, setIsGenerating] = useState<boolean>(false);

  // Toast Notification
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Article selection & XP gain handler
  const handleSelectArticle = (article: NewsArticle) => {
    // Mark as read
    setArticles((prev) =>
      prev.map((a) => (a.id === article.id ? { ...a, readStatus: true } : a))
    );

    // Award XP to user if logged in
    if (user && !article.readStatus) {
      const newXp = user.xp + 50;
      let newLevel = user.level;
      let newNextXp = user.nextLevelXp;

      if (newXp >= user.nextLevelXp) {
        newLevel += 1;
        newNextXp += 500;
        showToast(`🎉 레벨 업! Lv.${newLevel} 달성 (+50 XP)`);
      } else {
        showToast(`📖 만화 기사 읽기 완료! (+50 XP)`);
      }

      setUser({
        ...user,
        xp: newXp,
        level: newLevel,
        nextLevelXp: newNextXp,
        readArticlesCount: user.readArticlesCount + 1,
      });
    }

    setSelectedArticle(article);
  };

  // Like Article
  const handleLikeArticle = (articleId: string) => {
    setArticles((prev) =>
      prev.map((a) =>
        a.id === articleId ? { ...a, likesCount: (a.likesCount || 0) + 1 } : a
      )
    );
  };

  // Add Comment to Article
  const handleAddComment = (articleId: string, commentText: string) => {
    setArticles((prev) =>
      prev.map((a) =>
        a.id === articleId ? { ...a, commentsCount: (a.commentsCount || 0) + 1 } : a
      )
    );
  };

  // Share Article as Community Post
  const handleShareToCommunity = (article: NewsArticle) => {
    const newPost: CommunityPost = {
      id: `post_${Date.now()}`,
      title: `⚡ [추천만화] ${article.title}`,
      category: '인기 만화',
      authorName: user?.name || '익명 튜터',
      authorLevel: user?.level || 1,
      authorAvatar: user?.avatar || '익',
      createdAt: '방금 전',
      likesCount: 1,
      commentsCount: 0,
      isLiked: true,
      newsTitle: article.title,
      summary: article.summary,
      cartoonPanels: article.cartoonPanels,
      comments: [],
      views: 12,
    };

    setCommunityPosts([newPost, ...communityPosts]);
  };

  // Generate Custom 4-Panel Cartoon via Gemini AI Server Endpoint
  const handleGenerateCustomCartoon = async (topic: string, stock: string) => {
    setIsGenerating(true);
    try {
      const res = await fetch('/api/generate-cartoon', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ topic, stock }),
      });

      const data = await res.json();
      if (data.success && data.cartoon) {
        const generated = data.cartoon;
        const newArticle: NewsArticle = {
          id: `art_ai_${Date.now()}`,
          category: generated.category || 'AI 뉴스',
          readStatus: false,
          title: generated.title || topic,
          source: 'AI 실시간 브리핑',
          publishedTime: '방금 전',
          readTime: '3분 읽기',
          impactRating: generated.impactRating || 4,
          iconType: 'chip',
          summary: generated.summary || 'AI가 새로 작성한 4컷 만화 브리핑입니다.',
          likesCount: 1,
          commentsCount: 0,
          cartoonPanels: generated.panels || [],
          keyTakeaways: generated.keyTakeaways || [],
        };

        setArticles([newArticle, ...articles]);
        setSelectedArticle(newArticle);
        showToast('✨ AI 4컷 만화가 새로 생성되었습니다!');
      } else {
        // Fallback simulated AI cartoon if offline
        createFallbackCartoon(topic);
      }
    } catch (err) {
      console.error('Failed to generate cartoon via API, using client fallback:', err);
      createFallbackCartoon(topic);
    } finally {
      setIsGenerating(false);
    }
  };

  const createFallbackCartoon = (topic: string) => {
    const fallbackArticle: NewsArticle = {
      id: `art_fb_${Date.now()}`,
      category: 'AI 요약',
      readStatus: false,
      title: `[AI 만화] ${topic}`,
      source: 'CentLand AI Engine',
      publishedTime: '방금 전',
      readTime: '2분 읽기',
      impactRating: 5,
      iconType: 'chip',
      summary: `주제 "${topic}"에 관한 실시간 AI 분석 및 4컷 만화 브리핑입니다.`,
      likesCount: 5,
      commentsCount: 1,
      keyTakeaways: [
        'AI가 실시간 뉴스 흐름을 파악하여 핵심 요점을 도출했습니다.',
        '시장 참가자들의 주요 이슈 및 원인을 시각화했습니다.',
        '향후 주가 및 경제에 미칠 핵심 영향 포인트를 점검하세요.'
      ],
      cartoonPanels: [
        {
          panelNumber: 1,
          title: '1컷: 주요 뉴스 발생',
          sceneDescription: `${topic} 관련 뉴스 속보가 실시간 검색어 1위에 등극!`,
          characterSpeaker: 'AI 앵커',
          speechBubble: `"${topic}" 이슈가 시장의 가장 큰 관심사로 떠올랐습니다!`,
          visualIcon: 'building',
          keyTerm: '실시간 이슈',
          keyTermDefinition: '현재 투자자들이 가장 주목하고 있는 경제 키워드입니다.'
        },
        {
          panelNumber: 2,
          title: '2컷: 배경 원인 파악',
          sceneDescription: '전문가들이 데이터 차트를 보며 원인을 분석한다.',
          characterSpeaker: '애널리스트',
          speechBubble: '글로벌 경제 수급 불균형과 맞물려 파급력이 커지고 있어요!',
          visualIcon: 'handshake',
          keyTerm: '수급 (Supply & Demand)',
          keyTermDefinition: '매수세와 매도세의 힘겨루기 상태를 나타냅니다.'
        },
        {
          panelNumber: 3,
          title: '3컷: 파급 효과',
          sceneDescription: '기업들과 주식 시장의 차트 반응.',
          characterSpeaker: '시장 개미',
          speechBubble: '관련 섹터 기업들의 실적 전망치가 연달아 상향 조정되는군요!',
          visualIcon: 'chart',
          keyTerm: '모멘텀',
          keyTermDefinition: '주가 변동의 가속도를 나타내는 지표입니다.'
        },
        {
          panelNumber: 4,
          title: '4컷: 스마트 투자 대응',
          sceneDescription: '돋보기를 들고 현명한 판단을 내리는 유저.',
          characterSpeaker: '스마트 튜터',
          speechBubble: '단기 변동성에 흔들리지 말고 본질적인 기술력과 가치를 주목하세요!',
          visualIcon: 'graduation',
          keyTerm: '가치 투자',
          keyTermDefinition: '기업의 내재 가치에 기반하여 장기 투자하는 접근 방식입니다.'
        }
      ]
    };

    setArticles([fallbackArticle, ...articles]);
    setSelectedArticle(fallbackArticle);
    showToast('✨ AI 4컷 만화가 생성되었습니다!');
  };

  // Create Custom Post in Community
  const handleCreateCustomPost = async (
    title: string,
    category: string,
    summary: string,
    topic: string
  ) => {
    setIsGenerating(true);
    try {
      await handleGenerateCustomCartoon(topic, '');
      const latestArticle = articles[0];

      const newPost: CommunityPost = {
        id: `post_cust_${Date.now()}`,
        title,
        category,
        authorName: user?.name || '익명 튜터',
        authorLevel: user?.level || 1,
        authorAvatar: user?.avatar || '익',
        createdAt: '방금 전',
        likesCount: 1,
        commentsCount: 0,
        isLiked: true,
        summary: summary || `${topic}에 대한 4컷 만화 요약입니다.`,
        cartoonPanels: latestArticle ? latestArticle.cartoonPanels : mockArticles[0].cartoonPanels,
        comments: [],
        views: 10,
      };

      setCommunityPosts([newPost, ...communityPosts]);
      showToast('🎨 만화 게시글이 성공적으로 등록되었습니다!');
    } catch (e) {
      showToast('게시글 작성 중 오류가 발생했습니다.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleLikePost = (postId: string) => {
    setCommunityPosts((prev) =>
      prev.map((post) => {
        if (post.id === postId) {
          const newIsLiked = !post.isLiked;
          return {
            ...post,
            isLiked: newIsLiked,
            likesCount: newIsLiked ? post.likesCount + 1 : post.likesCount - 1,
          };
        }
        return post;
      })
    );
  };

  // If user opened landing screen view
  if (isLanding) {
    return (
      <>
        <LandingPage
          onOpenLogin={() => setShowLoginModal(true)}
          onGoDashboard={() => setIsLanding(false)}
        />
        {showLoginModal && (
          <LoginModal
            onClose={() => setShowLoginModal(false)}
            onLoginSuccess={(loggedUser) => {
              setUser(loggedUser);
              setIsLanding(false);
              showToast(`환영합니다, ${loggedUser.name}님!`);
            }}
          />
        )}
      </>
    );
  }

  return (
    <div className="min-h-screen bg-[#FAF9F6] text-gray-900 font-sans antialiased selection:bg-emerald-200">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-4 right-4 z-70 bg-gray-950 text-white text-xs font-bold px-4 py-3 rounded-2xl shadow-xl flex items-center gap-2 border border-gray-800 animate-slide-in">
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Header Navigation */}
      <Header
        user={user}
        onOpenLogin={() => setShowLoginModal(true)}
        onLogout={() => setUser(null)}
        onNavigateHome={() => {
          setShowStockDetail(false);
          setActiveTab('briefing');
        }}
        isLanding={isLanding}
        setIsLanding={setIsLanding}
      />

      <div className="flex max-w-7xl mx-auto min-h-[calc(100vh-57px)]">
        {/* Left Sidebar */}
        <Sidebar
          activeTab={activeTab}
          setActiveTab={(tab) => {
            setShowStockDetail(false);
            setActiveTab(tab);
          }}
          user={user}
        />

        {/* Main Content Area */}
        <main className="flex-1 p-6 sm:p-8 overflow-y-auto">
          {showStockDetail ? (
            <StockDetailView stock={selectedStock} onBack={() => setShowStockDetail(false)} />
          ) : (
            <>
              {activeTab === 'briefing' && (
                <TodayBriefing
                  user={user}
                  articles={articles}
                  onSelectArticle={handleSelectArticle}
                  onOpenStockDetail={(stock) => {
                    setSelectedStock(stock);
                    setShowStockDetail(true);
                  }}
                  onGenerateCustomCartoon={handleGenerateCustomCartoon}
                  isGenerating={isGenerating}
                />
              )}

              {activeTab === 'quests' && (
                <QuestsView
                  user={user}
                  quests={quests}
                  badges={badges}
                  onClaimQuestReward={(questId) => {
                    showToast('🎁 보상 수령 완료!');
                  }}
                />
              )}

              {activeTab === 'community' && (
                <CommunityView
                  posts={communityPosts}
                  user={user}
                  articles={articles}
                  onSelectPost={(post) => {
                    const tempArticle: NewsArticle = {
                      id: post.id,
                      category: post.category,
                      readStatus: true,
                      title: post.title,
                      source: post.authorName,
                      publishedTime: post.createdAt,
                      readTime: '3분 읽기',
                      impactRating: 5,
                      iconType: 'chip',
                      summary: post.summary,
                      likesCount: post.likesCount,
                      commentsCount: post.comments.length,
                      cartoonPanels: post.cartoonPanels,
                      keyTakeaways: ['유저들이 직접 공유한 인기 4컷 만화입니다.'],
                    };
                    setSelectedArticle(tempArticle);
                  }}
                  onLikePost={handleLikePost}
                />
              )}

              {activeTab === 'rankings' && (
                <RankingView
                  rankings={rankings}
                  currentUser={user}
                />
              )}

              {activeTab === 'profile' && (
                <ProfileView
                  user={user}
                  onUpdateInterests={(newInterests) => {
                    if (user) {
                      setUser({ ...user, interests: newInterests });
                      showToast('나의 관심사가 업데이트되었습니다.');
                    }
                  }}
                />
              )}
            </>
          )}
        </main>
      </div>

      {/* 4-Panel Cartoon Full Screen Modal View */}
      {selectedArticle && (
        <NewsComicModal
          article={selectedArticle}
          user={user}
          onClose={() => setSelectedArticle(null)}
          onLikeArticle={handleLikeArticle}
          onAddComment={handleAddComment}
          onShareToCommunity={handleShareToCommunity}
        />
      )}

      {/* Login Modal */}
      {showLoginModal && (
        <LoginModal
          onClose={() => setShowLoginModal(false)}
          onLoginSuccess={(loggedUser) => {
            setUser(loggedUser);
            showToast(`환영합니다, ${loggedUser.name}님!`);
          }}
        />
      )}
    </div>
  );
}
